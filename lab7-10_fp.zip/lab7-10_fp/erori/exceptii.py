class ValidationError(Exception):
    pass

class RepoError(Exception):
    pass

class UiError(Exception):
    pass
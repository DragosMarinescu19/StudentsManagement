from erori.exceptii import ValidationError
class ValidatorStudent:
    
    def validate_student(self,student):
        erori =''
        if student.get_id_student()<0:
            erori+='id student invalid\n'
        if student.get_nume()=='':
            erori+='nume invalid\n'
        if len(erori):
            raise ValidationError(erori)
from erori.exceptii import ValidationError

class ValidatorGrade:

    def validate_grade(self,grade):
        erori=''
        if 0>=grade.get_value_grade() or grade.get_value_grade()>10:
            erori+='invalid value grade'
        if len(erori)>0:
            raise ValidationError(erori)
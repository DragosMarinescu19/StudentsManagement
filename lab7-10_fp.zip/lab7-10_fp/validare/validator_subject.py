from erori.exceptii import ValidationError
class ValidatorSubject:
    
    def validate_subject(self,subject):
        erori=''
        if subject.get_id_subject()<0:
            erori+='id invalid\n'
        if subject.get_title()=='':
            erori+='nume invalid\n'
        if subject.get_name_teacher()=='':
            erori+='nume prof inbvalid\n'
        if len(erori)>0:
            raise ValidationError(erori)

from teste.tests import Teste
from business.service_students import ServiceStudents
from business.service_subject import ServiceSubjects
from business.service_grades import ServiceGrades
from persistenta.repo_students import FileRepoStudents
from persistenta.repo_subjects import FileRepoSubjects
from persistenta.repo_grades import FileRepoGrades
from validare.validator_student import ValidatorStudent
from validare.validator_subject import ValidatorSubject
from validare.validator_grade import ValidatorGrade
from prezentare.consola import Console


teste = Teste()
teste.ruleaza_toate_testele()
validator_student=ValidatorStudent()
students_file_path='C:\\Users\\marin\\OneDrive\\Desktop\\lab7-10_fp\\students.txt'
repo_students=FileRepoStudents(students_file_path)
validator_subject=ValidatorSubject()
subjects_file_path='C:\\Users\\marin\\OneDrive\\Desktop\\lab7-10_fp\\subjects.txt'
repo_subjects=FileRepoSubjects(subjects_file_path)
validator_grade=ValidatorGrade()
grades_file_path='C:\\Users\\marin\\OneDrive\\Desktop\\lab7-10_fp\\grades.txt'
repo_grades=FileRepoGrades(grades_file_path)
service_students=ServiceStudents(repo_students,validator_student)
service_subjects=ServiceSubjects(repo_subjects,validator_subject)
service_grades=ServiceGrades(repo_grades,repo_students,repo_subjects,validator_grade)
ui=Console(service_students,service_subjects,service_grades)
ui.run()



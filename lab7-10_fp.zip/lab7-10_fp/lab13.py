'''
Pentru un n dat generați toate secvențele de paranteze care se închid corect. Examplu: n=4
două soluții: (()) și ()()

    SOLUTIA FORMALIZATA
 
    Descrierea solutiei backtracking;

    soluție candidat:

    x = (x1,x2,..,xk) ,i∈(1,.. ,k), xi este un string cu elemente ce apartin multimii {'(',')'}

    condiție consistent:

    x= (x1, x2,. .. , xk) e consistent dacă pi<=n//2 si pd<=pi pentru ∀ i< j si fiecare element din xi are egal nr de paranteze 
    inchise cat si nr de paranteze deschise si sunt  egale cu numarul dat de la tastatura impartit la doi : n//2
    #pd <=n//2
    #pi <=pi

    condiție soluție:

    x= (x1, x2,. .. , xk) e soluţie dacă e consistent si k ==n si nr_pd == nr_pi
    


'''


def main():
    n = int(input('n= '))
    if n % 2 != 0:
        print("n trebuie să fie un număr par.")
        return
    solutions_list = []
    pi=0 # paranteze inchise
    pd=0 # paranteze deschise
    x=[]
    backrecursiv(x, n, pd, pi, solutions_list)
    print("Soluții:", solutions_list)
    result=backiterativ(n)
    print(result)

def backrecursiv(x, n, pd, pi, solutions_list):
    if len(x) == n:
        solutions_list.append("".join(x))
        return

    if pd<n//2:
        x.append('(')
        backrecursiv(x, n, pd + 1, pi, solutions_list)
        x.pop()

    if pi<pd:
        x.append(')')
        backrecursiv(x, n, pd, pi + 1, solutions_list)
        x.pop()

def backiterativ(n):
    result = []
    stack = [("(", 1, 0)]  # (current_str, pd, pi)

    while stack:
        current_str,pd, pi = stack.pop()
        

        if len(current_str) == n:
            if pd == pi:
                result.append(current_str)
        else:
            if pd < n // 2:
                stack.append((current_str + '(', pd + 1, pi))

            if pi < pd:
                stack.append((current_str + ')', pd, pi + 1))

    return result



if __name__ == '__main__':
    main()
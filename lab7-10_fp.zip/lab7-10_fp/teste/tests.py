from domeniu.student import Student
from validare.validator_student import ValidatorStudent
from erori.exceptii import ValidationError,RepoError
from persistenta.repo_students import RepoStudents,FileRepoStudents
from business.service_students import ServiceStudents
from persistenta.repo_subjects import RepoSubjects,FileRepoSubjects
from domeniu.subject import Subject
class Teste:
    def __init__(self):
       pass

    def __ruleaza_teste_domeniu_student(self):
        print('Starting student domain tests')
        self.__id_student = 1
        self.__nume='Alex'
        self.__student=Student(self.__id_student,self.__nume)
        assert self.__student.get_id_student()==self.__id_student
        assert self.__student.get_nume()==self.__nume
        self.__alt_nume='Dragos'
        self.__alt_student_acelasi_id=Student(self.__id_student,self.__alt_nume)
        #assert self.__student==self.__alt_student_acelasi_id
        print('Student domain tests finished')

    def __ruleaza_teste_validare_student(self):
        print('starting student validation tests...')
        self.__validator_student =ValidatorStudent()
        self.__validator_student.validate_student(self.__student)
        self.__id_student_invalid = -1
        self.__nume_invalid=''
        self.__student_invalid=Student(self.__id_student_invalid,self.__nume_invalid)
        #try:
           # self.__validator_student.validate_student(self.__student_invalid)
           # assert False
       # except ValidationError as ve:
           # assert str(ve)=='id invalid\nnume invalid\n'
        print('student validation tests finished')

    def __goleste_fisier(self,students_file_path):
        with open (students_file_path,'w') as f:
            f.write('') # se inchide singur fisierul
        

    def __ruleaza_teste_adaugare_student_repo(self):
        print('starting student add to repo tests...')
        #self.__repo_students = RepoStudents()
        students_file_path='C:\\Users\\marin\\OneDrive\\Desktop\\lab7-10_fp\\teste\\test_students.txt'
        self.__goleste_fisier(students_file_path)
        self.__repo_students=FileRepoStudents(students_file_path)
        #assert len(self.__repo_students)==0
        self.__repo_students.adauga_student(self.__student)
        student_gasit=self.__repo_students.cauta_student_dupa_id(self.__id_student)
        assert student_gasit==self.__student
        assert student_gasit.get_nume()==self.__student.get_nume()
        #assert len(self.__repo_students)==1
        try:
            self.__repo_students.adauga_student(self.__alt_student_acelasi_id)
            assert False
        except RepoError as re:
            assert str(re)=='student existent'
        print('student add repo tests finished ')

    def __ruleaza_teste_adaugare_student_service(self):
        print('startng student add to service tests...')
        students_file_path='C:\\Users\\marin\\OneDrive\\Desktop\\lab7-10_fp\\teste\\test_students.txt'
        self.__goleste_fisier(students_file_path)
        self.__repo_students=FileRepoStudents(students_file_path)
        self.__service_students=ServiceStudents(self.__repo_students,self.__validator_student)
        #assert self.__service_students.numar_studenti()==0
        self.__service_students.adauga_student(self.__id_student,self.__nume)
        #assert self.__service_student.numar_studenti()==1
        student_gasit=self.__service_students.cauta_student_dupa_id(self.__id_student)
        assert student_gasit==self.__student
        assert student_gasit.get_nume()==self.__student.get_nume()
        try:
            self.__service_students.adauga_student(self.__id_student,self.__alt_nume)
            assert False
        except RepoError as re:
            assert str(re)=='student existent'


        print('student add service tests finished ')

    def __ruleaza_teste_domeniu_disciplina(self):
        self.__id_subject=1
        self.__title = 'History'
        self.__name_teacher='Ana'
        self.__alt_title='matematica'
        self.__subject=Subject(self.__id_subject,self.__title,self.__name_teacher)
        assert self.__subject.get_id_subject()==self.__id_subject
        assert self.__subject.get_title()==self.__title
        assert self.__subject.get_name_teacher()==self.__name_teacher
        self.__alt_subject_acelasi_id=Subject(self.__id_subject,self.__alt_title,self.__name_teacher)

    def __ruleaza_teste_adaugare_subject_repo(self):
        print('starting subject add to repo tests...')
        #self.__repo_subjects = RepoSubjects()
        subjects_file_path='C:\\Users\\marin\\OneDrive\\Desktop\\lab7-10_fp\\teste\\test_subjects.txt'
        self.__goleste_fisier(subjects_file_path)
        self.__repo_subjects=FileRepoSubjects(subjects_file_path)
        assert len(self.__repo_subjects)==0
        self.__repo_subjects.adauga_subject(self.__subject)
        subject_gasit=self.__repo_subjects.cauta_subject_dupa_id(self.__id_subject)
        assert subject_gasit==self.__subject
        assert subject_gasit.get_title()==self.__subject.get_title()
        assert len(self.__repo_subjects)==1
        
        print('subject add repo tests finished ')
        

    def ruleaza_toate_testele(self):
        print('Starting tests...')
        self.__ruleaza_teste_domeniu_student()
        self.__ruleaza_teste_validare_student()
        self.__ruleaza_teste_adaugare_student_repo()
        self.__ruleaza_teste_adaugare_student_service()
        self.__ruleaza_teste_domeniu_disciplina()
        self.__ruleaza_teste_adaugare_subject_repo()

from erori.exceptii import RepoError
from domeniu.gradeDTO import GradeDTO
from domeniu.grade import Grade
class RepoGrades:

    def __init__(self):
        self._grades={}

    def adauga_grade(self,grade):
        id_grade=grade.get_id_grade()
        if id_grade in self._grades:
            raise RepoError('grade existent')
        self._grades[id_grade]=grade

    def __len__(self):
        return len(self._grades)
    
    def get_all(self):
        return [self._grades[id_grade] for id_grade in self._grades]
    
class FileRepoGrades(RepoGrades):
    def __init__(self,grades_file_path):
        self.__grades_file_path=grades_file_path
        RepoGrades.__init__(self)

    def __read_all_grades_from_file(self):
        with open(self.__grades_file_path,'r') as f:
            self._grades.clear()
            lines=f.readline()
            for line in lines:
                line=line.strip()
                if line!='':
                    parti=line.split(',')                    
                    id_grade=int(parti[0])
                    id_student=int(parti[1])
                    id_subject=int(parti[2])
                    value_grade=float(parti[3])
                    gradeDTO=GradeDTO(id_grade,id_student,id_subject,value_grade)
                    self._grades[id_grade]=gradeDTO


    def __append_grade_to_file(self,grade):
        with open(self.__grades_file_path,'a') as f:
            f.write(str(grade)+'\n')

    def adauga_grade(self, grade):
        self.__read_all_grades_from_file()
        RepoGrades.adauga_grade(self,grade)
        self.__append_grade_to_file(grade)

    def __len__(self):
        self.__read_all_grades_from_file()
        return RepoGrades.__len__(self)
    
    def get_all(self):
        self.__read_all_grades_from_file()
        return RepoGrades.get_all(self)
        
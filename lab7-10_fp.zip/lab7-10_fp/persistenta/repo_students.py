from domeniu.student import Student
from erori.exceptii import RepoError
import os


class RepoStudents:
    
    def __init__(self):
        self._students={}

    def __len__(self):
        return len(self._students)
    
    def adauga_rstudent(self,student):
        id_student=student.get_id_student()
        if id_student in self._students:
            raise RepoError('student existent')
        self._students[id_student]=student

    
    def adauga_student(self,student):
        id_student=student.get_id_student()
        if id_student in self._students:
            raise RepoError('student existent')
        self._students[id_student]=student

    def sterge_student_dupa_id(self,id_student):
        if id_student in self._students:
            self._students.pop(id_student)
            return self._students

    def cauta_student_dupa_id(self,id_student):
        if id_student not in self._students:
            raise RepoError('student inexistent')
        return self._students[id_student]
    
    def modifica_student_dupa_id(self, id_student, nume):
        if id_student in self._students:
            self._students[id_student].set_nume(nume)
            return self._students
        else:
            raise RepoError('id inexistent')
        
    def bubble_sort(self,list):

        """
        Sort array using Bubble Sort.
        
        Time complexity: O(n ^ 2) / Tetha(n ^ 2) / Omega(n)
        Space complexity: O(1)
        """
        #sorted = False
        #while not sorted:
        sorted = True 
        for i in range(len(list)-1):
            if self.cmp(list[i],list[i+1])>0:
                list[i], list[i + 1] = list[i + 1], list[i]
                sorted = False
        if sorted==False:
            self.bubble_sort(list)
        return list
    
    def cmp(self, student_1, student_2):
        name_1 = student_1.get_nume()
        name_2 = student_2.get_nume()

        if name_1 is None or name_2 is None:
            return 0  

        if name_1 > name_2:
            return 1
        if name_1 == name_2:
            return int(student_1.get_id_student()) - int(student_2.get_id_student())

        return 0
           

    '''def get_all(self): # recursiva
        students=[]
        conditie=True
        for id_student in self._students:
            if self._students[id_student] not in students:
                students.append(self._students[id_student])
            else:
                conditie=False
        if conditie==False:
            self.get_all()
        return students'''
        
    def get_all(self):
        return [self._students[id_student] for id_student in self._students]
    
class FileRepoStudents(RepoStudents):
    
    def __init__(self,students_file_path):
        self.__students_file_path=students_file_path
        RepoStudents.__init__(self)
        self.__new_text_file()
        

    def __read_all_students_from_file(self):
        with open(self.__students_file_path,'r') as f:
            self._students.clear()
            lines=f.readlines()
            for line in lines:
                line=line.strip()
                if line !="":
                    parti=line.split(',')
                    id_student=int(parti[0])
                    nume=parti[1]
                    student=Student(id_student,nume)
                    self._students[id_student]=student

    
    def __new_text_file(self):
        if not os.path.exists(self.__students_file_path):
            return
        
        with open(self.__students_file_path, 'r') as file:
            for line in file:
                if line!='':
                    id_student = line.strip()
                    nume = next(file).strip()
                    student=Student(id_student,nume)
                    id_student=int(id_student)
                    self._students[id_student] = student
                

    def salvare_in_fisier(self,student):
        with open(self.__students_file_path, 'a') as file:
            file.write(f"{student.get_id_student()}\n{student.get_nume()}\n")
      

    def __len__(self):
        self.__new_text_file()
        #self.__read_all_students_from_file()
        return RepoStudents.__len__(self)
    
    def modifica_student_dupa_id(self, student):
        id_student = student.get_id_student()
        nume = student.get_nume()
        RepoStudents.modifica_student_dupa_id(self, id_student, nume)
        ok = 0
        modified_lines = []
        
        with open(self.__students_file_path, 'r') as f:
            self._students.clear()
            lines = f.readlines()
            
            for line in lines:
                if line.strip() != '':
                    if ok == 1:
                        modified_lines.append(f"{student.get_nume()}\n")
                        ok = 0
                    elif str(student.get_id_student()) == line.strip():
                        ok = 1
                        modified_lines.append(line)
                    else:
                        modified_lines.append(line)

        with open(self.__students_file_path, 'w') as f:
            f.writelines(modified_lines)

        #RepoStudents.modifica_student_dupa_id(self, student)


    '''
    
    def modifica_student_dupa_id(self,id_student,nume):
        modified_lines=[]
        with open(self.__students_file_path,'r') as f:
            self._students.clear()
            lines=f.readlines()
            for line in lines:
                line=line.strip()
                if line!='':
                    if id_student==line.strip():
                        modified_lines=[line.replace(str(next(line)),str(nume))]
                    else:
                        modified_lines.append(line)

        with open(self.__students_file_path,'w') as f:
            f.writelines(modified_lines)
        RepoStudents.modifica_student_dupa_id(self,id_student,nume)'''
    
    
    
    def __append_student_to_file(self,student):
        with open(self.__students_file_path,'a') as f:
            f.write(str(student)+'\n')
    '''
    def sterge_student_dupa_id(self,id_student):
        with open(self.__students_file_path,'r') as f:
            self._students.clear()
            lines=f.readlines()
            modified_file=[line for line in lines if str(id_student) not in line]
            with open (self.__students_file_path,'w') as f:
                f.writelines(modified_file)
        RepoStudents.sterge_student_dupa_id(self,id_student)
        #self.salvare_in_fisier()
        '''
    
    def sterge_student_dupa_id(self, id_student):
        with open(self.__students_file_path, 'r') as f:
            self._students.clear()
            lines = f.readlines()
            modified_file = []

            skip_next_line = False

            for line in lines:
                if str(id_student) in line:
                    skip_next_line = True
                else:
                    if not skip_next_line:
                        modified_file.append(line)

                    skip_next_line = False

            with open(self.__students_file_path, 'w') as f:
                f.writelines(modified_file)

        RepoStudents.sterge_student_dupa_id(self, id_student)
        

    def adauga_rstudent(self, student):
        #self.__read_all_students_from_file()
        self.__new_text_file()
        RepoStudents.adauga_rstudent(self,student)
        self.salvare_in_fisier(student)
        #self.__append_student_to_file(student)
        
        
    def adauga_student(self, student):
        #self.__read_all_students_from_file()
        self.__new_text_file()
        RepoStudents.adauga_student(self,student)
        #self.__append_student_to_file(student)
        self.salvare_in_fisier(student)

    def ordonare_studenti(self,students):
        self._students.clear()
        
        with open(self.__students_file_path,'w') :
            pass
        for student in students:
            with open(self.__students_file_path, 'a') as file:
                file.write(f"{student.get_id_student()}\n{student.get_nume()}\n")
            '''id_student=student.get_id_student()
            nume=student.get_nume()
            self._students[id_student]=Student(id_student,nume)'''
        
            



    def cauta_student_dupa_id(self, id_student):
        self.__new_text_file()
        #self.__read_all_students_from_file()
        return RepoStudents.cauta_student_dupa_id(self,id_student)
    
    
    
    def get_all(self):
        #self.__read_all_students_from_file()
        self.__new_text_file()
        return RepoStudents.get_all(self)
    

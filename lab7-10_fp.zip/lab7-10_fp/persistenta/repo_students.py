from domeniu.student import Student
from erori.exceptii import RepoError


class RepoStudents:
    
    def __init__(self):
        self._students={}

    def __len__(self):
        return len(self._students)
    
    def adauga_rstudent(self,student):
        id_student=student.get_id_student()
        if id_student in self._students:
            raise RepoError('student existent')
        self._students[id_student]=student

    
    def adauga_student(self,student):
        id_student=student.get_id_student()
        if id_student in self._students:
            raise RepoError('student existent')
        self._students[id_student]=student

    def sterge_student_dupa_id(self,id_student):
        if id_student in self._students:
            self._students.pop(id_student)
            return self._students

    def cauta_student_dupa_id(self,id_student):
        if id_student not in self._students:
            raise RepoError('student inexistent')
        return self._students[id_student]
    
    def modifica_student_dupa_id(self,id_student,nume):
        if id_student in self._students:
           self._students[nume]=nume
           return self._students
    
    def get_all(self):
        return [self._students[id_student] for id_student in self._students]
    
class FileRepoStudents(RepoStudents):
    
    def __init__(self,students_file_path):
        self.__students_file_path=students_file_path
        RepoStudents.__init__(self)

    def __read_all_students_from_file(self):
        with open(self.__students_file_path,'r') as f:
            self._students.clear()
            lines=f.readlines()
            for line in lines:
                line=line.strip()
                if line !="":
                    parti=line.split(',')
                    id_student=int(parti[0])
                    nume=parti[1]
                    student=Student(id_student,nume)
                    self._students[id_student]=student

    def __len__(self):
        self.__read_all_students_from_file()
        return RepoStudents.__len__(self)
    
    def modifica_student_dupa_id(self,id_student,nume):
        modified_lines=[]
        with open(self.__students_file_path,'r') as f:
            self._students.clear()
            lines=f.readlines()
            for line in lines:
                line=line.strip()
                if line!='':
                    parti=line.split(',')
                    if id_student==int(parti[0]):
                        modified_lines=[line.replace(str(parti[1]),str(nume))]
                    else:
                        modified_lines.append(line)

        with open(self.__students_file_path,'w') as f:
            f.writelines(modified_lines)
        RepoStudents.modifica_student_dupa_id(self,id_student,nume)
    
    
    
    def __append_student_to_file(self,student):
        with open(self.__students_file_path,'a') as f:
            f.write(str(student)+'\n')

    def sterge_student_dupa_id(self,id_student):
        with open(self.__students_file_path,'r') as f:
            self._students.clear()
            lines=f.readlines()
            modified_file=[line for line in lines if str(id_student) not in line]
            with open (self.__students_file_path,'w') as f:
                f.writelines(modified_file)
        RepoStudents.sterge_student_dupa_id(self,id_student)
        

    def adauga_rstudent(self, student):
        self.__read_all_students_from_file()
        RepoStudents.adauga_rstudent(self,student)
        self.__append_student_to_file(student)
        #self.__write_students_to_file()
        
    def adauga_student(self, student):
        self.__read_all_students_from_file()
        RepoStudents.adauga_student(self,student)
        self.__append_student_to_file(student)
        #self.__write_students_to_file()

    def cauta_student_dupa_id(self, id_student):
        self.__read_all_students_from_file()
        return RepoStudents.cauta_student_dupa_id(self,id_student)
    
    def get_all(self):
        self.__read_all_students_from_file()
        return RepoStudents.get_all(self)
    

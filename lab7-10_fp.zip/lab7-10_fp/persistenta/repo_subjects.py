from domeniu.subject import Subject
from erori.exceptii import RepoError
class RepoSubjects:
    
    def __init__(self):
        self._subjects={}

    def __len__(self):
        return len(self._subjects)
    
    def adauga_subject(self,subject):
        id_subject=subject.get_id_subject()
        if id_subject in self._subjects:
            raise RepoError('subject existent')
        self._subjects[id_subject]=subject

    def adauga_rsubject(self,subject):
        id_subject=subject.get_id_subject()
        if id_subject in self._subjects:
            raise RepoError('subject existent')
        self._subjects[id_subject]=subject


    def cauta_subject_dupa_id(self,id_subject):
        if id_subject not in self._subjects:
            raise RepoError('Disciplina inexistenta')
        return self._subjects[id_subject]
    
    def sterge_subject_dupa_id(self,id_subject):
        if id_subject in self._subjects:
            self._subjects.pop(id_subject)
            return self._subjects
    
    def get_all(self):
        return [self._subjects[id_subject] for id_subject in self._subjects]
        


class FileRepoSubjects(RepoSubjects):
    
    def __init__(self,subjects_file_path):
        self.__subjects_file_path=subjects_file_path
        RepoSubjects.__init__(self)

    def __read_all_subjects_from_file(self):
        with open(self.__subjects_file_path,'r') as f:
            self._subjects.clear()
            lines=f.readlines()
            for line in lines:
                line=line.strip()
                if line !='':
                    parti=line.split(',')
                    id_subject=int(parti[0])
                    title=parti[1]
                    name_teacher=parti[2]
                    subject=Subject(id_subject,title,name_teacher)
                    self._subjects[id_subject]=subject

    def __len__(self):
        self.__read_all_subjects_from_file()
        return RepoSubjects.__len__(self)
    
    def __append_subject_to_file(self,subject):
        with open (self.__subjects_file_path,'a') as f:
            f.write(str(subject)+'\n')
    
    def adauga_subject(self,subject):
        self.__read_all_subjects_from_file()
        RepoSubjects.adauga_subject(self,subject)
        self.__append_subject_to_file(subject)

    def adauga_rsubject(self,subject):
        self.__read_all_subjects_from_file()
        RepoSubjects.adauga_rsubject(self,subject)
        self.__append_subject_to_file(subject)

    def sterge_subject_dupa_id(self,id_subject):
        with open(self.__subjects_file_path,'r') as f:
            self._subjects.clear()
            lines=f.readlines()
            modified_file=[line for line in lines if str(id_subject) not in line]
            with open (self.__subjects_file_path,'w') as f:
                f.writelines(modified_file)
        RepoSubjects.sterge_subject_dupa_id(self,id_subject)

    def cauta_subject_dupa_id(self, id_subject):
        self.__read_all_subjects_from_file()
        return RepoSubjects.cauta_subject_dupa_id(self,id_subject)

    def get_all(self):
        self.__read_all_subjects_from_file()
        return RepoSubjects.get_all(self)
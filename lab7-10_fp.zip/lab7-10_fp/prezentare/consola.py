import random
from faker import Faker
from erori.exceptii import ValidationError,RepoError,UiError

class Console:

    def __init__(self,service_students,service_subjects,service_grades):
        self.__service_subjects=service_subjects
        self.__service_students=service_students
        self.__service_grades=service_grades
        self.__commands={
            'add_student':self.__ui_add_student,
            'print_students':self.__ui_print_students,
            'add_subject':self.__ui_add_subject,
            'print_subjects':self.__ui_print_subjects,
            'add_grade':self.__ui_add_grade,
            'print_grades':self.__ui_print_grades,
            'top_k_students':self.__ui_top_k_valedictorians,
            'remove_student':self.__ui_remove_student,
            'remove_subject':self.__ui_remove_subject,
            'cauta_student':self.__ui_cauta_student,
            'cauta_disciplina':self.__ui_cauta_disciplina,
            'modifica_student':self.__ui_modifica_student,
            'add_rstudent':self.__ui_adauga_student_random,
            'add_rsubject':self.__ui_adauga_subject_random

        }

    


    def __ui_modifica_student(self,params):
        if len(params)!=2:
            raise UiError('invalid number of parameters')
        try:
            id_student=int(params[0])
            nume=params[1]
            self.__service_students.modifica_student(id_student,nume)
        except ValueError:
            raise UiError('invalid numerical value')

    def __ui_cauta_student(self,params):
        if len(params)!=1:
            raise UiError('invalid number of parameters')
        try:
            id_student=int(params[0])
            self.__service_students.cauta_student(id_student)
        except ValueError:
            raise UiError('invalid numerical value')
        
    def __ui_cauta_disciplina(self,params):
        if len(params)!=1:
            raise UiError('invalid number of parameters')
        try:
            id_subject=int(params[0])
            self.__service_subjects.cauta_subject(id_subject)
        except ValueError:
            raise UiError('invalid numerical value')

    def __ui_remove_subject(self,params):
        if len(params)!=1:
            raise UiError('invalide  number of params')
        try:
            id_subject=int(params[0])
            self.__service_subjects.sterge_subject(id_subject)
        except ValueError:
            raise UiError('invalid numerical value')    

    def __ui_remove_student(self,params):
        if len(params)!=1:
            raise UiError('invalid numebr of paranmeters')
        try:
            id_student=int(params[0])
            self.__service_students.sterge_student(id_student)
        except ValueError:
            raise UiError('invalid numerical value')
    
    def __ui_top_k_valedictorians(self,params):
        if len(params)!=1:
            raise UiError('invalid number of parameters')
        try:
            k=int(params[0])
            valedictorians = self.__service_grades.top_k_valedictorians(k)
            if len(valedictorians)==0:
                raise UiError('no students')
            for valedictorian in valedictorians :
                print(valedictorian)
        except ValueError:
            raise UiError('invalid numerical value')


    def __ui_add_grade(self,params):
        if len(params)!=4:
            raise UiError('invalid number of parameters')
        try:
            print(params)
            id_grade=int(params[0])
            id_student=int(params[1])
            id_subject=int(params[2])
            value_grade=float(params[3])
            self.__service_grades.adauga_grade(id_grade,id_student,id_subject,value_grade)
        except ValueError:
            raise UiError('invalid numerical value!!!')
        

            
    def __ui_print_grades(self,params):
        grades=self.__service_grades.get_all_grades()
        if len(grades)==0:
            raise UiError('no grades yet')
        for grade in grades:
            print(grade)

    
    def __ui_print_subjects(self,params):
        subjects=self.__service_subjects.get_all_subjects()
        if len(subjects)==0:
            raise UiError('no subjects')
        for subject in subjects:
            print(subject)

    def __ui_add_subject(self,params):
        if len(params)!=3:
            raise UiError('invalid number of parameters')
        try:
            id_subject=int(params[0])
            title=params[1]
            name_teacher=params[2]
            self.__service_subjects.adauga_subject(id_subject,title,name_teacher)
        except ValueError:
            raise UiError('Invalid value')
        
    def __ui_adauga_subject_random(self,params):
        global list
        fake=Faker()
        list=['ASC','Info','FP','Logica computationala','Analiza']
        id_subject=random.randint(1,100)
        title=random.choice(list)
        name_teacher=fake.name()
        self.__service_subjects.adauga_rsubject(id_subject,title,name_teacher)

    def __ui_print_students(self,params):
        students=self.__service_students.get_all_students()
        if len(students)==0:
            raise UiError('No students yet')
        for student in students:
            print(student)


    def __ui_adauga_student_random(self,params):
        fake=Faker()
        nume=fake.name()
        id_student=random.randint(1,100)
        self.__service_students.adauga_rstudent(id_student,nume)

    def __ui_add_student(self,params):
        if len(params)!=2:
            raise UiError('invalid number of parameters')
        try:
            id_student=int(params[0])
            nume=params[1]
            self.__service_students.adauga_student(id_student,nume)
        except ValueError:
            raise UiError('Invalid value')


    def run(self):
        while True:
            command =input('>>>')
            command=command.strip()
            if command =='':
                continue
            if command=='exit':
                return
            parts=command.split()
            command_name=parts[0]
            params=parts[1:]
            if command_name in self.__commands:
                try:
                    self.__commands[command_name](params)#functie
                except ValidationError as ve:
                    print(f'Validation error:{ve}')
                except RepoError as re:
                    print(f'repo error: {re}')
                except UiError as ue:
                    print(f'Ui errror :{ue}')
            else:
                print('comanda invalida!')

from domeniu.subject import Subject

class ServiceSubjects:

    def __init__(self,__repo_subjects,__validator_subject):
        self.__repo_subjects=__repo_subjects
        self.__validator_subject=__validator_subject

    def ordonare_subjects(self):
        subjects =self.__repo_subjects.get_all()
        subjects=self.__repo_subjects.shell_sort(subjects)
        self.__repo_subjects.ordonare_subjects(subjects)

    def numar_subject(self):
        return len(self.__repo_subjects)
    
    def adauga_rsubject(self,id_subject,title,name_teacher):
        subject=Subject(id_subject,title,name_teacher)
        self.__repo_subjects.adauga_rsubject(subject)

    def adauga_subject(self,id_subject,title,name_teacher):
        subject=Subject(id_subject,title,name_teacher)
        self.__validator_subject.validate_subject(subject)
        self.__repo_subjects.adauga_subject(subject)

    def sterge_subject(self,id_subject):
        self.__repo_subjects.sterge_subject_dupa_id(id_subject)
        
    def cauta_subject(self,id_subject):
        print(self.__repo_subjects.cauta_subject_dupa_id(id_subject))

    def cauta_subject_dupa_id(self,id_subject):
        return self.__repo_subjects.cauta_subject_dupa_id(id_subject)
    
    def get_all_subjects(self):
        return self.__repo_subjects.get_all()
    
    

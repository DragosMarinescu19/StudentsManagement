from domeniu.student import Student
class ServiceStudents:

    def __init__(self,__repo_students,__validator_student):
        self.__repo_students=__repo_students
        self.__validator_student=__validator_student

    def adauga_rstudent(self,id_student,nume):
        student=Student(id_student,nume)
        self.__repo_students.adauga_rstudent(student)
        
    def adauga_student(self,id_student,nume):
        student=Student(id_student,nume)
        self.__validator_student.validate_student(student)
        self.__repo_students.adauga_student(student)

    def sterge_student(self,id_student):
        self.__repo_students.sterge_student_dupa_id(id_student)

    def cauta_student(self,id_student):
        print(self.__repo_students.cauta_student_dupa_id(id_student))

    def modifica_student(self,id_student,nume):
        self.__repo_students.modifica_student_dupa_id(id_student,nume)


    def numar_studenti(self):
        return len(self.__repo_students)

    def cauta_student_dupa_id(self,id_student):
        return self.__repo_students.cauta_student_dupa_id(id_student)
    
    def get_all_students(self):
        return self.__repo_students.get_all()



from domeniu.gradeDTO import GradeDTO
from domeniu.grade import Grade
from domeniu.valedictorianDTO import ValedictorianDTO
class ServiceGrades:
    def __init__(self,repo_grades,repo_students,repo_subjects,validator_grade):
        self.__repo_grades=repo_grades
        self.__repo_students=repo_students
        self.__repo_subjects=repo_subjects
        self.__validator_grade=validator_grade

    def adauga_grade(self,id_grade,id_student,id_subject,value_grade):
       
        self.__repo_students.cauta_student_dupa_id(id_student)
        self.__repo_subjects.cauta_subject_dupa_id(id_subject)
        grade=GradeDTO(id_grade,id_student,id_subject,value_grade)
        self.__validator_grade.validate_grade(grade)
        self.__repo_grades.adauga_grade(grade)
        
    def best_students(self):
        grades_dtos=self.__repo_grades.get_all()
        result=[]
        for grade_dto in grades_dtos :
            if grade_dto.get_value_grade()>=9.5:
                student=self.__repo_students.cauta_student_dupa_id(grade_dto.get_id_student())
                subject=self.__repo_subjects.cauta_subject_dupa_id(grade_dto.get_id_subject())
                grade=Grade(grade_dto.get_id_grade(),student,subject,grade_dto.get_value_grade())
                result.append(grade)
        return result

    def numar_grades(self):
        return len(self.__repo_grades)
    
    def get_all_grades(self):
        grades_dtos=self.__repo_grades.get_all()
        result=[]
        for grade_dto in grades_dtos:
            student=self.__repo_students.cauta_student_dupa_id(grade_dto.get_id_student())
            subject=self.__repo_subjects.cauta_subject_dupa_id(grade_dto.get_id_subject())
            grade=Grade(grade_dto.get_id_grade(),student,subject,grade_dto.get_value_grade())
            result.append(grade)
        return result
    
    def __compute_averages(self):
        averages = {}# iteram pe note
        grade_dtos=self.__repo_grades.get_all()
        for grade_dto in grade_dtos:
            id_student = grade_dto.get_id_student()
            value_grade=grade_dto.get_value_grade()
            if id_student not in averages:
                averages[id_student]=[0,0]#suma notelor si cate is
            averages[id_student][0]+=value_grade
            averages[id_student][1]+=1
        return averages

    
    def top_k_valedictorians(self,k):
        averages=self.__compute_averages()
        result=[]
        for id_student in averages:
            student_average=averages[id_student][0]/averages[id_student][1]
            student_name=self.__repo_students.cauta_student_dupa_id(id_student).get_nume()
            valedictorianDTO=ValedictorianDTO(id_student,student_name,student_average)
            result.append(valedictorianDTO)  
        result.sort(key=lambda x:x.get_student_average(),reverse=True)
        return result[:k]


    

class Subject:

    def __init__(self,__id_subject,__title,__name_teacher):
        self.__id_subject=__id_subject
        self.__title=__title
        self.__name_teacher=__name_teacher

    def get_id_subject(self):
        return self.__id_subject
    
    def get_title(self):
        return self.__title
    
    def get_name_teacher(self):
        return self.__name_teacher
    
    def set_title(self,title):
        self.__title=title

    def set_name_teacher(self,name_teacher):
        self.__name_teacher=name_teacher

    def __eq__(self,other):
        return self.__id_subject==other.__id_subject
    
    def __str__(self):
        return f'{self.__id_subject},{self.__title},{self.__name_teacher}'
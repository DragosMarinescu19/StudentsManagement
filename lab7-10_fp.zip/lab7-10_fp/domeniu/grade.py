class Grade:

    def __init__(self,id_grade,student,subject,value_grade):
        self.__id_grade=id_grade
        self.__student=student
        self.__subject=subject
        self.__value_grade=value_grade

    def get_id_grade(self):
        return self.__id_grade
    
    def get_student(self):
        return self.__student
    
    def get_subject(self):
        return self.__subject
    
    def get_value_grade(self):
        return self.__value_grade
    
    def set_subject(self,value):
        self.__subject=value

    def set_student(self,value):
        self.__student=value
    
    def set_value_grade(self,value):
        self.__value_grade=value

    def __str__(self):
        return f'{self.__id_grade} {self.__student.get_nume()} a luat la materia {self.__subject.get_title()} nota {self.__value_grade}'
    

class ValedictorianDTO:

    def __init__(self,id_student,student_name,student_average):
        self.__id_student=id_student
        self.__student_name=student_name
        self.__student_average=student_average

    def get_id_student(self):
        return self.__id_student
    
    def get_student_name(self):
        return self.__student_name
    
    def get_student_average(self):
        return self.__student_average
    
    def __str__(self):
        return f'{self.__id_student}:{self.__student_name},cu media {self.__student_average}'
        

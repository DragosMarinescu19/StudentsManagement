class GradeDTO:
    def __init__(self,id_grade,id_student,id_subject,value_grade):
        self.__id_grade=id_grade
        self.__id_student=id_student
        self.__id_subject=id_subject
        self.__value_grade=value_grade

    def get_id_grade(self):
        return self.__id_grade
    
    def get_id_subject(self):
        return self.__id_subject
    
    def get_id_student(self):
        return self.__id_student
    
    def get_value_grade(self):
        return self.__value_grade
    
    def __str__(self):
        return f'{self.__id_grade},{self.__id_student},{self.__id_subject},{self.__value_grade}'